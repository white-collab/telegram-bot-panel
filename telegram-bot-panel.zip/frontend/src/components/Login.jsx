
import React, { useState } from 'react';
import axios from 'axios';

export default function Login({ onLogin }) {
  const [user, setUser] = useState(''), [pass, setPass] = useState('');
  
  const submit = async () => {
    const form = new URLSearchParams();
    form.append('username', user);
    form.append('password', pass);
    const { data } = await axios.post('http://backend:8000/login', form);
    onLogin(data.access_token);
  };
  
  return (
    <div>
      <input placeholder="Operator" onChange={e => setUser(e.target.value)} />
      <input placeholder="Password" type="password" onChange={e => setPass(e.target.value)} />
      <button onClick={submit}>Login</button>
    </div>
  );
}
