
import os
import logging
from aiogram import Bot, Dispatcher, types
from httpx import AsyncClient
from dotenv import load_dotenv

load_dotenv()
API_TOKEN = os.getenv('BOT_TOKEN')
BACKEND = os.getenv('BACKEND_URL')

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)
http = AsyncClient()

@dp.message_handler(commands=['start'])
async def cmd_start(msg: types.Message):
    await msg.answer("Привет! Отправь своё сообщение, и оператор свяжется с тобой.")

@dp.message_handler()
async def handle_message(msg: types.Message):
    data = {
        "telegram_id": msg.from_user.id,
        "username": msg.from_user.username,
        "text": msg.text,
    }
    try:
        await http.post(f"{BACKEND}/messages/", json=data)
        await msg.answer("Ваше сообщение отправлено оператору.")
    except Exception as e:
        logging.error(e)
        await msg.answer("Ошибка при отправке, попробуйте позже.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
